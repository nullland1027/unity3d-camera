using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{   
    public float speed;
    public GameObject cam;
    public GameObject front;
    public GameObject behind;
    public GameObject left;
    public GameObject right;
    public GameObject top;
    public CameraController cameraController;
    // Start is called before the first frame update
    void Start()
    {
        cam = GameObject.Find("Main Camera");
        front = GameObject.Find("Front");
        behind = GameObject.Find("Behind");
        left = GameObject.Find("Left");
        right = GameObject.Find("Right");
        top = GameObject.Find("Top");
        
    }

    // Update is called once per frame
    void Update()
    {
        // int q_times = 0;
        // int e_times = 0;
        // int position = 0;
        // if (Input.GetKeyDown(KeyCode.Q)) {
        //     q_times++;
        // }
        // if (Input.GetKeyDown(KeyCode.E)) {
        //     e_times++;
        // }
        // position =  System.Math.Abs(q_times - e_times);

        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        if (cam.transform.position.Equals(front.transform.position)) {
            
                moveHorizontal = 0.0f;
                moveVertical = 0.0f;
            
                moveHorizontal = Input.GetAxis("Horizontal");
                moveVertical = Input.GetAxis("Vertical");
                movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
            
            
        }
        if (cam.transform.position.Equals(behind.transform.position)) {
            moveHorizontal = Input.GetAxis("Horizontal");
            moveVertical = Input.GetAxis("Vertical");
            movement = new Vector3(-moveHorizontal, 0.0f, -moveVertical);
        }
        if (cam.transform.position.Equals(left.transform.position)) {
            moveHorizontal = Input.GetAxis("Horizontal");
            moveVertical = Input.GetAxis("Vertical");
            movement = new Vector3(moveVertical, 0.0f, -moveHorizontal);
        }
        if (cam.transform.position.Equals(right.transform.position)) {
            moveHorizontal = Input.GetAxis("Horizontal");
            moveVertical = Input.GetAxis("Vertical");
            movement = new Vector3(-moveVertical, 0.0f, moveHorizontal);
        }
        GetComponent<Rigidbody>().velocity = movement * speed;
    }
}
